package com.smtb.mqrestconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessageQueueRestConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessageQueueRestConsumerApplication.class, args);
	}

}
