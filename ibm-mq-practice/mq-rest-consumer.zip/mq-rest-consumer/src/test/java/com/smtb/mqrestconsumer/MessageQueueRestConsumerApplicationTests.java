package com.smtb.mqrestconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageQueueRestConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
